// Example posts
const posts = [
  {
    title: "Minimal blogs in 2025",
    date: "2025-09-20",
    author: "Vaishnavi",
    excerpt: "Why simple blogs still work.",
    content: "<p>Minimal blogs help focus on writing and reading.</p>",
    tags: ["writing", "design"]
  },
  {
    title: "Write for mobile",
    date: "2025-08-10",
    author: "Team Blog",
    excerpt: "How to make posts mobile-friendly.",
    content: "<p>Use short paragraphs, clear headings, and light images.</p>",
    tags: ["mobile", "ux"]
  }
];

let allPosts = posts;

// Render posts on screen
function render(list) {
  const container = document.getElementById("posts");
  container.innerHTML = "";

  // Build tag filter
  const allTags = [...new Set(list.flatMap(p => p.tags))];
  document.getElementById("tagFilter").innerHTML =
    "<option value=''>All</option>" +
    allTags.map(t => `<option>${t}</option>`).join("");

  // Show each post
  list.forEach(p => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h2>${p.title}</h2>
      <div class="meta">${p.author} • ${p.date}</div>
      <div class="excerpt">${p.excerpt}</div>
    `;

    // Tags
    const tagsDiv = document.createElement("div");
    p.tags.forEach(t => {
      const tag = document.createElement("span");
      tag.className = "tag";
      tag.textContent = t;
      tag.onclick = () => {
        document.getElementById("tagFilter").value = t;
        filter();
      };
      tagsDiv.appendChild(tag);
    });
    card.appendChild(tagsDiv);

    // Read button
    const btn = document.createElement("button");
    btn.className = "read";
    btn.textContent = "Read";
    btn.onclick = () => openModal(p);
    card.appendChild(btn);

    container.appendChild(card);
  });
}

// Filter posts
function filter() {
  const q = document.getElementById("q").value.toLowerCase();
  const tag = document.getElementById("tagFilter").value.toLowerCase();

  const filtered = allPosts.filter(p => {
    const text = (p.title + p.excerpt + p.content + p.tags.join(" ")).toLowerCase();
    return (!q || text.includes(q)) &&
           (!tag || p.tags.map(t => t.toLowerCase()).includes(tag));
  });

  render(filtered);
}

// Modal open/close
function openModal(p) {
  document.getElementById("modalTitle").textContent = p.title;
  document.getElementById("modalMeta").textContent = `${p.author} • ${p.date}`;
  document.getElementById("modalBody").innerHTML = p.content;
  document.getElementById("modal").style.display = "flex";
}

document.getElementById("closeBtn").onclick = () =>
  document.getElementById("modal").style.display = "none";

document.getElementById("modal").onclick = e => {
  if (e.target.id === "modal") e.currentTarget.style.display = "none";
};

// Events
document.getElementById("q").oninput = filter;
document.getElementById("tagFilter").onchange = filter;

// Initial load
render(allPosts);
